require 'httparty'
require_relative "recipe"

puts Recipe.for("chocolate")
